﻿//Name: Stephanie Mohler
//Date: 13 March 2022
//Description: Stuck in a Time Loop Individual Assign. One
    using System;

namespace StuckinaTimeLoop
{
    class Program
    {
        static void Main(string[] args)
        {
            int N = int.Parse(Console.ReadLine());
            int count = 1;

            if(N >=1 && N <= 100)
            {
                while (count <= N)
                {
                    Console.Write(count + " " + "Abracadabra");
                    Console.WriteLine();
                    count = count + 1;
                }

            }
            else
            {
                Console.Write("Please enter a valid integer between 1 and 100");
            };
        }
    }
}